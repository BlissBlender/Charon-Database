╔══════════════════════════════════════════╗
║           N E R A I   M A N I F E S T S       ║
║         Steam Depot Manifest Delivery       ║
╚══════════════════════════════════════════╝

  Game:      Unknown
  App ID:    244210
  Package:   Lua + Depot Manifests
  Files:     19
  Tool ver:  v1.0.0
  Generated: 2026-06-24 12:17:49 UTC

──────────────────────────────────────────

Place the .lua file where your unlocker expects it.
Depot .manifest files are ready for Steam manifest
download tools (e.g. SteamTools, DepotDownloader, SteamCMD).

Need another game? Use /gen <appid> in Discord.

──────────────────────────────────────────
  Nerai Vault  •  v1.0.0  •  2026-06-24