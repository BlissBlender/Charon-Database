-- 4248790's Lua and Manifest Created by Hubcap Manifest
-- Substrate: Emergence
-- Created: September 24, 2026 at 20:11:56 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4248790) -- Substrate: Emergence
-- MAIN APP DEPOTS
addappid(4248791, 1, "1d4287c3751ec70390fdf2d7d5153d3d7aed658f86addd3c4a88fc8d1d86503b") -- Depot 4248791
setManifestid(4248791, "9018575474793603778", 226529489)