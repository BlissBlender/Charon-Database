-- 5216930's Lua and Manifest Created by Hubcap Manifest
-- Scam With Your Friends Playtest
-- Created: September 26, 2026 at 00:05:07 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(5216930) -- Scam With Your Friends Playtest
-- MAIN APP DEPOTS
addappid(5216931, 1, "b8f2978b380cce83216a913c9a7e30949df0f660311fb298dab0465bf15442f2") -- Depot 5216931
setManifestid(5216931, "8331392754508950057", 5746099476)