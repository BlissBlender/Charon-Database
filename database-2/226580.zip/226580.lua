-- 226580's Lua and Manifest Created by Hubcap Manifest
-- F1 2014
-- Created: January 20, 2026 at 10:35:58 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 11
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(226580) -- F1 2014
-- MAIN APP DEPOTS
addappid(226581, 1, "82e69e56ea0b02901fdd9a839ae3f76977a73110992690aea090cccc59e7e77c") -- F1 2014 Data
setManifestid(226581, "4613960749704229591", 5065843309)
addappid(226582, 1, "4d911cda78df33d3e3db0c7f331c4707378dbbe856fdfe588b2e7f4718b6c3fb") -- F1 2014 Exe
setManifestid(226582, "8183018018876525320", 16946797)
addappid(226584, 1, "887a828ddeed0c801b94ae3916313ea8b7423689afd2a6a01cf163c4778f7d02") -- F1 2014 Brazilian
setManifestid(226584, "6650189235212474999", 338964502)
addappid(226585, 1, "f2691e44dcdab7fd2a5e7980a84b481fa726f487c3752383ecf91302e3ca6c8f") -- F1 2014 English
setManifestid(226585, "1080952306243440258", 302760809)
addappid(226586, 1, "08b0a04217a8a6c3ec33f911bd0c9f2702347ed4118824fb7770929d4acbac00") -- F1 2014 French
setManifestid(226586, "7299966855149431532", 284852747)
addappid(226587, 1, "d5cf43bbad762270d24a27990f241cc5b14865054aad89f3b83c88bc16a887f2") -- F1 2014 German
setManifestid(226587, "5989016827646145845", 335182182)
addappid(226588, 1, "eba845f22811617dd0765650d63f507c6c89a2df1a02004bdd7ba3bca7cfe734") -- F1 2014 Italian
setManifestid(226588, "2822008376012479084", 371734694)
addappid(226589, 1, "fd5e8a40bc0d5ae5a72db23ba4d166129e2192aa7163f3cefcd0a22c03c07b5a") -- F1 2014 Japanese
setManifestid(226589, "7270518009656973811", 273915985)
addappid(226590, 1, "aaa01a1f2b753abf477d425c347f7b4f0139d8ef17a8ef2088f7735ecc234ebc") -- F1 2014 Polish
setManifestid(226590, "3390472675442172220", 316410374)
addappid(226592, 1, "acb13dadc13592ffff0174013ff2b4fd6cd599a52db67e7d952a492f40dbdb24") -- F1 2014 Spanish
setManifestid(226592, "2801803765728758930", 341588963)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(226583) -- Depot 226583 (empty depot)