-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 3606480.lua
addappid(3606480)
addtoken(3606480, "9695571449896312778")